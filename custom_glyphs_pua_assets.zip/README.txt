Custom Glyphs — Private Use Area Mapping
========================================
This package contains deduplicated glyph images extracted from your artwork and
a mapping assigning each glyph to the Unicode Private Use Area (PUA) starting at U+E000.

Files:
- glyphs/ : 1-bit PNGs of each unique glyph (black on transparent when imported)
- PUA_mapping.csv / .json : mapping table from codepoint to glyph image filename
- How to make a font (quick options):
  * FontForge: File > New > Encoding "Unicode BMP"; then Element > Font Info...
    Set Em Size to 1024. Import each PNG into its assigned slot (see mapping).
    Finally File > Generate Fonts... choose OpenType (CFF) or TrueType.
  * IcoMoon: Import the SVG/PNG icons and assign the codepoints shown here.
